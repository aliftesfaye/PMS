-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2024 at 06:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `activity_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `activity_status` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `deletedAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_milestone` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_members`
--

CREATE TABLE `activity_members` (
  `activity_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `activity_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `project_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `deletedAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `sub_task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `activity_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `comment` varchar(255) NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `division_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `sector_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `head_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `document_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `document_type_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `document` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

CREATE TABLE `document_types` (
  `document_type_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`document_type_id`, `document_type`, `created_by`, `updated_by`, `createdAt`, `updatedAt`, `is_deleted`, `deletionAt`, `deletedBy`) VALUES
('5f517578-443c-11ef-8e35-b05cda965850', 'Project Charter', NULL, NULL, '2024-07-17 14:58:56', '2024-07-17 14:58:56', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `major_tasks`
--

CREATE TABLE `major_tasks` (
  `Major_task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `activity_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `major_task_members`
--

CREATE TABLE `major_task_members` (
  `major_task_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Major_task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `project_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `major_task_status` varchar(255) NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `read` tinyint(1) DEFAULT 0,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organizationmedias`
--

CREATE TABLE `organizationmedias` (
  `organization_media_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `organization_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `media_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `url` varchar(255) NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `organization_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `acronym` varchar(255) DEFAULT NULL,
  `background` varchar(255) DEFAULT NULL,
  `header_color` varchar(255) DEFAULT NULL,
  `footer_color` varchar(255) DEFAULT NULL,
  `background_color` varchar(255) DEFAULT NULL,
  `copyright_text` varchar(255) DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `permission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `group_code` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permission_id`, `name`, `createdAt`, `updatedAt`, `group_code`) VALUES
('042b3d2d-f0bd-11ee-a446-c01803d475fd', 'get teams', '2024-04-02 08:48:22', '2024-04-02 08:48:22', 7),
('0f94a3e8-0da4-11ef-84b6-b48c9dac3d22', 'update user', '2024-05-09 03:30:20', '2024-05-09 03:30:20', 2),
('0f94acc0-0da4-11ef-84b6-b48c9dac3d22', 'delete user', '2024-05-09 03:30:20', '2024-05-09 03:30:20', 2),
('20912e6d-1f53-11ef-be51-b05cda965850', 'get trash', '2024-05-31 15:38:41', '2024-05-31 15:38:41', 9),
('25b8c824-1c5a-11ef-bb5b-b05cda965850', 'view project members', '2024-05-27 20:51:29', '2024-05-27 20:51:29', 3),
('2f33cdc1-f009-11ee-bd81-c01803d475fd', 'change password', '2024-04-01 11:20:40', '2024-04-01 11:20:40', 2),
('306a3e55-2241-11ef-a40a-c01803d49f59', 'get milestone', '2024-06-04 09:07:48', '2024-06-04 09:07:48', 10),
('355eef05-f0b9-11ee-a446-c01803d475fd', 'create organization', '2024-04-02 08:20:48', '2024-04-02 08:20:48', 1),
('355ef6c3-f0b9-11ee-a446-c01803d475fd', 'update organization', '2024-04-02 08:20:48', '2024-04-02 08:20:48', 1),
('37959d81-1355-11ef-bcd0-b05cda965850', 'view sector', '2024-05-16 09:22:23', '2024-05-16 09:22:23', 1),
('3c9491b1-36d1-11ef-a7a0-c01803d49f59', 'comment on sub task', '2024-06-30 13:09:20', '2024-06-30 13:09:20', 6),
('414c220c-f009-11ee-bd81-c01803d475fd', 'delete organization unit', '2024-04-01 11:21:19', '2024-04-01 11:21:19', 1),
('414c2ab4-f009-11ee-bd81-c01803d475fd', 'delete organization', '2024-04-01 11:21:19', '2024-04-01 11:21:19', 1),
('4673c802-1e4e-11ef-be51-b05cda965850', 'get profile', '2024-05-30 08:31:18', '2024-05-30 08:31:18', 2),
('4673d532-1e4e-11ef-be51-b05cda965850', 'view password', '2024-05-30 08:31:18', '2024-05-30 08:31:18', 2),
('55094e25-0df5-11ef-9350-b48c9dac3d22', 'create task', '2024-05-09 13:14:03', '2024-05-09 13:14:03', 5),
('550954bf-0df5-11ef-9350-b48c9dac3d22', 'update task', '2024-05-09 13:14:03', '2024-05-09 13:14:03', 5),
('555b9d74-f0b9-11ee-a446-c01803d475fd', 'create organization unit', '2024-04-02 08:21:29', '2024-04-02 08:21:29', 1),
('555ba555-f0b9-11ee-a446-c01803d475fd', 'update organization unit', '2024-04-02 08:21:29', '2024-04-02 08:21:29', 1),
('5e67218a-2a31-11ef-b41f-c01803d49f59', 'get structure2', '2024-06-14 11:34:27', '2024-06-14 11:34:27', 11),
('6031481e-1e4d-11ef-be51-b05cda965850', 'get structure', '2024-05-30 08:25:04', '2024-05-30 08:25:04', 1),
('62a21d4f-0df5-11ef-9350-b48c9dac3d22', 'get task', '2024-05-09 13:14:44', '2024-05-09 13:14:44', 5),
('62a22447-0df5-11ef-9350-b48c9dac3d22', 'get all task', '2024-05-09 13:14:44', '2024-05-09 13:14:44', 5),
('64383a86-36d1-11ef-a7a0-c01803d49f59', 'view comment on sub task', '2024-06-30 13:09:44', '2024-06-30 13:09:44', 6),
('6fe619f9-1e4d-11ef-be51-b05cda965850', 'get organization', '2024-05-30 08:25:33', '2024-05-30 08:25:33', 1),
('74118ed8-36c3-11ef-a7a0-c01803d49f59', 'view comment on activity', '2024-06-30 11:30:49', '2024-06-30 11:30:49', 4),
('799466dd-0df4-11ef-9350-b48c9dac3d22', 'create activity', '2024-05-09 13:08:00', '2024-05-09 13:08:00', 4),
('79946ef6-0df4-11ef-9350-b48c9dac3d22', 'update activity', '2024-05-09 13:08:00', '2024-05-09 13:08:00', 4),
('7cacae67-f0b9-11ee-a446-c01803d475fd', 'change user status', '2024-04-02 08:22:49', '2024-04-02 08:22:49', 2),
('7cacb6b1-f0b9-11ee-a446-c01803d475fd', 'create team', '2024-04-02 08:22:49', '2024-04-02 08:22:49', 7),
('85e8ca24-0df3-11ef-9350-b48c9dac3d22', 'get all project', '2024-05-09 13:01:02', '2024-05-09 13:01:02', 3),
('85e8d424-0df3-11ef-9350-b48c9dac3d22', 'get specific project', '2024-05-09 13:01:02', '2024-05-09 13:01:02', 3),
('86ae5a26-f0b9-11ee-a446-c01803d475fd', 'update team', '2024-04-02 08:23:17', '2024-04-02 08:23:17', 7),
('86ae647e-f0b9-11ee-a446-c01803d475fd', 'delete team', '2024-04-02 08:23:17', '2024-04-02 08:23:17', 7),
('8bc30fe2-fdab-11ee-889c-c01803d475fd', 'Delete project', '2024-04-18 19:45:28', '2024-04-18 19:45:28', 3),
('8bc31df5-fdab-11ee-889c-c01803d475fd', 'delete activity', '2024-04-18 19:45:28', '2024-04-18 19:45:28', 4),
('921e960f-1e4e-11ef-be51-b05cda965850', 'view project members profile', '2024-05-30 08:33:28', '2024-05-30 08:33:28', 3),
('9907dce2-0da5-11ef-84b6-b48c9dac3d22', 'get all user', '2024-05-09 03:42:51', '2024-05-09 03:42:51', 2),
('9907e4ed-0da5-11ef-84b6-b48c9dac3d22', 'get specific user', '2024-05-09 03:42:51', '2024-05-09 03:42:51', 2),
('9f3a1a3e-440b-11ef-8e35-b05cda965850', 'view document', '2024-07-17 09:09:45', '2024-07-17 09:09:45', 12),
('9f3a3abc-440b-11ef-8e35-b05cda965850', 'edit document', '2024-07-17 09:09:45', '2024-07-17 09:09:45', 12),
('a5488f51-1c56-11ef-bb5b-b05cda965850', 'get all role', '2024-05-27 20:26:26', '2024-05-27 20:26:26', 2),
('ae7ba5bb-440b-11ef-8e35-b05cda965850', 'download document', '2024-07-17 09:10:12', '2024-07-17 09:10:12', 12),
('ae7bc265-440b-11ef-8e35-b05cda965850', 'delete document', '2024-07-17 09:10:12', '2024-07-17 09:10:12', 12),
('b4315a39-36c3-11ef-a7a0-c01803d49f59', 'comment on activity', '2024-06-30 11:32:36', '2024-06-30 11:32:36', 4),
('b5d82643-0df4-11ef-9350-b48c9dac3d22', 'get all activity', '2024-05-09 13:09:37', '2024-05-09 13:09:37', 4),
('b5d82d4a-0df4-11ef-9350-b48c9dac3d22', 'get activity', '2024-05-09 13:09:37', '2024-05-09 13:09:37', 4),
('be30828d-3388-11ef-813a-b05cda965850', 'add project to department', '2024-06-26 08:52:55', '2024-06-26 08:52:55', 11),
('c2064335-0df7-11ef-9350-b48c9dac3d22', 'get all teams', '2024-05-09 13:31:49', '2024-05-09 13:31:49', 7),
('c3751b5f-0df6-11ef-9350-b48c9dac3d22', 'update sub task', '2024-05-09 13:24:36', '2024-05-09 13:24:36', 6),
('c5c6eeb6-fdab-11ee-889c-c01803d475fd', 'Delete Major task', '2024-04-18 19:47:03', '2024-04-18 19:47:03', 4),
('c5c6f7ad-fdab-11ee-889c-c01803d475fe', 'delete task', '2024-04-18 19:47:03', '2024-04-18 19:47:03', 5),
('d03a82c9-f775-11ee-baf0-c01803d4a116', 'register new user', '2024-04-01 11:20:40', '2024-04-01 11:20:40', 2),
('d1bdedf8-1c57-11ef-bb5b-b05cda965850', 'get home', '2024-05-27 20:34:52', '2024-05-27 20:34:52', 8),
('d975de92-1c57-11ef-bb5b-b05cda965850', 'get admin dashboard', '2024-05-27 20:35:05', '2024-05-27 20:35:05', 8),
('dce2f829-0df5-11ef-9350-b48c9dac3d22', 'get sub task', '2024-05-09 13:18:02', '2024-05-09 13:18:02', 6),
('dce2fde1-0df5-11ef-9350-b48c9dac3d22', 'get all sub task', '2024-05-09 13:18:02', '2024-05-09 13:18:02', 6),
('dd00ad1b-fdab-11ee-889c-c01803d475fd', 'delete sub task', '2024-04-18 19:47:55', '2024-04-18 19:47:55', 6),
('dd00b44f-fdab-11ee-889c-c01803d475fg', 'create sub task', '2024-04-18 19:47:55', '2024-04-18 19:47:55', 6),
('e168618d-1c57-11ef-bb5b-b05cda965850', 'get project dashboard', '2024-05-27 20:35:17', '2024-05-27 20:35:17', 8),
('e562ac9a-1e4d-11ef-be51-b05cda965850', 'create sector', '2024-05-30 08:28:26', '2024-05-30 08:28:26', 1),
('e562bfc8-1e4d-11ef-be51-b05cda965850', 'get organization unit', '2024-05-30 08:28:26', '2024-05-30 08:28:26', 1),
('ee4921a4-0df2-11ef-9350-b48c9dac3d22', 'create project', '2024-05-09 12:56:48', '2024-05-09 12:56:48', 3),
('ee4928bc-0df2-11ef-9350-b48c9dac3d22', 'update project', '2024-05-09 12:56:48', '2024-05-09 12:56:48', 3),
('f50a1cc4-1c57-11ef-bb5b-b05cda965850', 'get workspace', '2024-05-27 20:35:50', '2024-05-27 20:35:50', 4),
('f6aa786d-2ed0-11ef-8adb-c01803d49f59', 'Assign member to sector', '2024-06-20 08:47:18', '2024-06-20 08:47:18', 11),
('fd0f6b57-1e4d-11ef-be51-b05cda965850', 'get sector', '2024-05-30 08:29:00', '2024-05-30 08:29:00', 1),
('fd0f7821-1e4d-11ef-be51-b05cda965850', 'update sector', '2024-05-30 08:29:00', '2024-05-30 08:29:00', 1),
('fd0f8432-1e4d-11ef-be51-b05cda965850', 'delete sector', '2024-05-30 08:29:00', '2024-05-30 08:29:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `overall_progress` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `division_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_members`
--

CREATE TABLE `project_members` (
  `project_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `project_related` tinyint(1) NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `name`, `project_related`, `created_by`, `updated_by`, `createdAt`, `updatedAt`, `is_deleted`, `deletionAt`, `deletedBy`) VALUES
('09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'Project Member', 1, NULL, NULL, '2024-04-01 08:29:33', '2024-04-01 08:29:33', 0, NULL, NULL),
('636f3125-8244-426c-8905-cf8b5045aacd', 'User', 0, NULL, NULL, '2024-04-01 12:42:38', '2024-04-01 12:42:38', 0, NULL, NULL),
('b459daa4-f776-11ee-baf0-c01803d4a116', 'Project Manager', 1, NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('b459e14e-f776-11ee-baf0-c01803d4a116', 'Technical Manager', 1, NULL, NULL, '2024-04-01 08:28:22', '2024-04-01 08:28:22', 0, NULL, NULL),
('c170f434-248d-4e45-a0b0-5101bab7e8e1', 'System Admin', 0, NULL, NULL, '2024-04-01 12:37:24', '2024-06-20 12:57:37', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `role_permission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `permission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`role_permission_id`, `role_id`, `permission_id`, `created_by`, `updated_by`, `createdAt`, `updatedAt`, `is_deleted`, `deletionAt`, `deletedBy`) VALUES
('002356fc-98a1-40f6-bed6-dc10c6e154d1', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('011e54bd-3701-4382-bf89-8809913e62d1', 'b459daa4-f776-11ee-baf0-c01803d4a116', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('01b9f34d-03b3-4b50-854c-d8c8739616f6', '7055b9e5-5e7d-4e5a-818f-739306b82d4a', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-16 13:21:36', '2024-04-16 13:21:36', 0, NULL, NULL),
('01d45395-555a-40cc-87de-62002f4487b8', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'c3751b5f-0df6-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('021af1de-e4c9-40bf-b7bf-53db1d19e319', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('023b7375-faa2-4903-8edf-730eaa6b4a08', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'dd00b44f-fdab-11ee-889c-c01803d475fg', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('03401b28-f107-4d8f-9d1f-750c46cf481b', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'f6aa786d-2ed0-11ef-8adb-c01803d49f59', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('03d9758a-f6cb-4837-bcb2-294983085637', 'b6d22469-4895-4905-9503-16ca4e2502ab', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-14 07:36:57', '2024-04-14 07:36:57', 0, NULL, NULL),
('05365be7-45d2-45f9-a6ff-74bc3c327cca', 'b459daa4-f776-11ee-baf0-c01803d4a116', '9f3a1a3e-440b-11ef-8e35-b05cda965850', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('06edd1bf-ca13-46f1-9ca2-c8d36f4b0b12', 'd57b5e31-cc33-4d8b-8e0b-2c9c4aa8732e', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:35:20', '2024-04-03 07:35:20', 0, NULL, NULL),
('08278733-0518-4597-8540-3d4fdf50c145', 'b459daa4-f776-11ee-baf0-c01803d4a116', '64383a86-36d1-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('094859b4-9eac-4ffd-8d67-7278ad2f2758', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'dce2f829-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('09a401e3-7ca5-478c-84ff-0b1b3eef0bf1', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '62a22447-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('0a30c362-8faf-4b6e-9131-a87ab703cd32', 'c1b0890d-99ac-4722-9990-5db4fc5cf669', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-14 08:15:36', '2024-04-14 08:15:36', 0, NULL, NULL),
('0a499c74-6ea0-420f-8d37-c5d0963a9353', '24c1e2e7-d7e8-479f-8503-7ced3fa721e0', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:30:45', '2024-04-08 03:30:45', 0, NULL, NULL),
('0b06468a-3a8c-4c65-a4c1-7ec1684bb1a0', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '550954bf-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('0b7e7670-f0e2-4a3c-852c-90aae3d66a4a', '9acbeb94-bc30-4872-96f1-b5540cb83402', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('0e51f896-6048-4aaf-8462-f8df6f664eb2', 'f6e69899-dd55-45c9-8e0e-ae1b0653ffb2', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 09:22:34', '2024-04-03 09:22:34', 0, NULL, NULL),
('100858d5-5782-4223-88fc-18dd183f071c', 'd7f695ea-58b9-4e32-888f-201490402802', 'c5c6eeb6-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('118265cc-3e8b-4d6e-9e3d-72ce2c22143c', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '85e8ca24-0df3-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('11909dd7-9a8a-406f-b1e6-2f663ff4fabf', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('11af5021-3981-4603-8eea-6d0cc2b92ede', 'b459daa4-f776-11ee-baf0-c01803d4a116', '79946ef6-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('126b6ea2-40df-41ab-a847-c71e08b1ad67', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '4673c802-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('12ae7714-1e4e-40af-a984-284b79aad44f', 'dde498b7-507d-48fc-8e45-051fabfd849e', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:43:04', '2024-04-08 03:43:04', 0, NULL, NULL),
('13235d26-15d1-4199-a336-424636f0f57a', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('13575da0-fef7-4281-92c6-6f57a8e269c7', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '5e67218a-2a31-11ef-b41f-c01803d49f59', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('14a401a5-8e76-4a88-9897-57301fddb9ba', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('15493f3e-2478-445a-80c0-fddb9926db5a', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('15bca673-b909-48df-98cd-8ec914dd10a5', '9acbeb94-bc30-4872-96f1-b5540cb83402', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:12', '2024-04-03 08:19:12', 0, NULL, NULL),
('16f32ec8-f8bc-4473-95ba-b89b1664bd2d', '900d3318-e4f9-4871-afe5-6984dc78350e', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:28:30', '2024-04-08 03:28:30', 0, NULL, NULL),
('19e8fb18-5f3d-4de3-988f-00e1d82c04d1', 'b4820f3e-b0d6-4370-ae2c-52442b993be2', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 10:42:59', '2024-04-03 10:42:59', 0, NULL, NULL),
('1b2a6041-84b3-4ad4-a341-0be420c1e6dd', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'd1bdedf8-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('1b4ea7f6-e004-4db2-a752-faa60a718cfd', 'b459daa4-f776-11ee-baf0-c01803d4a116', '25b8c824-1c5a-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('1b7c8c22-acdc-4bfd-b13e-72de192a3c65', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'b5d82643-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('1b899fd9-9171-4e61-a134-9f9bb3211bcb', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('1bb9b988-8cc6-49f0-af9d-569a1aa18022', 'd7f695ea-58b9-4e32-888f-201490402802', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('1bbac686-fcfd-4ff1-8aef-65ffcf567817', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'c5c6f7ad-fdab-11ee-889c-c01803d475fe', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('1d7ee39b-6fe4-4131-99f6-a8445cba70d2', 'd7f695ea-58b9-4e32-888f-201490402802', '8bc31df5-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('1e8f9ac6-ddeb-49f1-ac94-24260937000b', '9acbeb94-bc30-4872-96f1-b5540cb83402', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('1e9ff6d6-5110-4607-adba-9b45c4c137eb', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('1eb144c4-86a7-4df0-aeb0-5ce1374bd943', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'e168618d-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('205287c7-01f3-4992-ab64-fffad00f1c32', 'dde498b7-507d-48fc-8e45-051fabfd849e', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:43:03', '2024-04-08 03:43:03', 0, NULL, NULL),
('20e4173f-a85d-48d3-9793-74bed979c8fc', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'dce2fde1-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('214ff333-caeb-4f97-a5d1-baf6abf7bdf9', '42cf3984-740d-4d4f-9138-ad598ee802a6', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 10:45:27', '2024-04-03 10:45:27', 0, NULL, NULL),
('21abd1d9-b5b8-4d47-8be4-1d3b6c49567f', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'dce2fde1-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('227393e1-fbe2-4faf-ba7b-c5b52fac08cc', 'b459daa4-f776-11ee-baf0-c01803d4a116', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 07:12:54', '2024-07-17 07:12:54', 0, NULL, NULL),
('234eb0d4-cf0f-41a3-8033-984190b48eb7', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'c5c6f7ad-fdab-11ee-889c-c01803d475fe', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('240a6402-e8c0-48d7-a0ae-5f3e56fb46e2', '636f3125-8244-426c-8905-cf8b5045aacd', 'b5d82643-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-01 13:09:50', '2024-07-01 13:09:50', 0, NULL, NULL),
('2526f73b-88b3-4eb7-a594-e850bc6fb48c', '636f3125-8244-426c-8905-cf8b5045aacd', 'e168618d-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-01 13:09:51', '2024-07-01 13:09:51', 0, NULL, NULL),
('26600de6-9eba-4ee4-b292-86c4786623fc', '636f3125-8244-426c-8905-cf8b5045aacd', '921e960f-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-07-01 13:09:51', '2024-07-01 13:09:51', 0, NULL, NULL),
('282e574b-be41-4e2c-a34a-47a2998f3a51', 'd7f695ea-58b9-4e32-888f-201490402802', 'dd00ad1b-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('29aed5e3-cd51-41f8-92fc-82ffb1c357d2', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('29ca6674-dd56-4c3a-a596-577c69e0449c', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'e562ac9a-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('2b271eea-21fb-40fe-a341-fc1286c5a494', '9acbeb94-bc30-4872-96f1-b5540cb83402', '7cacae67-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('2b8b4d66-8fb4-4dd9-8d41-fd9b901386e1', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'b5d82643-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('2d962ca9-0c77-4389-bfe4-0335c0fca694', '806b3124-f9f5-4fe3-ae28-577a746d72f3', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 09:25:58', '2024-04-03 09:25:58', 0, NULL, NULL),
('3159df14-7453-4046-bfd5-02e60f96236a', 'c9795f8f-fe90-483e-9731-1e778562fe9a', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 13:35:26', '2024-04-03 13:35:26', 0, NULL, NULL),
('330259ea-8a15-495b-9f83-d449137c954a', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('330c6b22-fdc6-4759-b1bd-31c12427b8b3', 'a712d7ee-eebb-496e-ab69-bc450abe0845', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-04 13:19:10', '2024-04-04 13:19:10', 0, NULL, NULL),
('35036d62-407d-41ac-af22-663a8882adba', '900d3318-e4f9-4871-afe5-6984dc78350e', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:28:30', '2024-04-08 03:28:30', 0, NULL, NULL),
('375bd038-6648-4f8d-a026-014c0d6c6308', '9acbeb94-bc30-4872-96f1-b5540cb83402', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('38d7b983-8b6f-481e-9736-be68949589cf', 'a7e389b7-01d6-4c17-8b70-213d72e7b371', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-06-20 11:37:54', '2024-06-20 11:37:54', 0, NULL, NULL),
('39b17c16-23ae-4865-8f36-726228f08f80', 'b459daa4-f776-11ee-baf0-c01803d4a116', '8bc31df5-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('3a4f3859-6720-4def-bbf3-1654abe90ec7', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'ee4921a4-0df2-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('3d900d90-bc2f-493f-886e-6f03b2000482', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('3e0fc7aa-f83a-4f8f-b6d3-6fac9c4b4bc5', 'b459e14e-f776-11ee-baf0-c01803d4a116', '85e8d424-0df3-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('3e397a10-7daa-47ec-8eb6-04f15da3efde', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('3ed7cfa7-727a-46a1-95fc-a30c29b9c005', 'b459e14e-f776-11ee-baf0-c01803d4a116', '550954bf-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('3f04ecc8-fe0a-4b9e-881e-58356f57c8e8', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('3f69a11d-0526-44ad-812a-1180668ca95d', 'dd5cade5-4809-4417-bebe-76c0daff162b', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:27:51', '2024-04-08 03:27:51', 0, NULL, NULL),
('401660df-160f-4b43-b2fd-df98c08f78d8', 'b459e14e-f776-11ee-baf0-c01803d4a116', '62a22447-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('41780249-c1e8-44ee-9413-3ff4416dbfba', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('44aeb17d-a351-4746-b2ea-b6f83f5867ce', 'b459daa4-f776-11ee-baf0-c01803d4a116', '85e8d424-0df3-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('4581ab9d-a578-4fe7-a9d1-524bf392976c', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'dd00b44f-fdab-11ee-889c-c01803d475fg', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('45d2d594-be50-4b42-a438-6794e65dcfa4', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '85e8d424-0df3-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('466cac75-17e7-4d19-8313-877af20c9421', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('467a793d-4730-41fb-9a36-cf1574b032b3', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '0f94acc0-0da4-11ef-84b6-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('47ee262f-eed6-41b1-8187-d6fcb3c17ea5', 'b459daa4-f776-11ee-baf0-c01803d4a116', '62a22447-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('4938e741-79d1-433c-ab46-ae849a1a50f5', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('4a16a31e-9842-451e-82db-feda94e56512', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('4bc8bbf5-b205-406a-8c0c-4b464a830170', 'bc65f319-75a4-47ee-8016-19415f435efd', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-16 13:26:29', '2024-04-16 13:26:29', 0, NULL, NULL),
('4c557328-7d0f-4127-b9dd-5374c24bd9f2', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'd1bdedf8-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('4ca27845-7a64-4b13-a4a9-eacb3720a1f1', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'c5c6eeb6-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 07:12:54', '2024-07-17 07:12:54', 0, NULL, NULL),
('4dd6bf74-5aa5-4100-90b8-51aa6cf3678c', 'd7f695ea-58b9-4e32-888f-201490402802', 'c5c6f7ad-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('4e0142ac-145d-4b2d-9df6-bb58642605b8', 'dde498b7-507d-48fc-8e45-051fabfd849e', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:43:04', '2024-04-08 03:43:04', 0, NULL, NULL),
('4ee70621-01a3-4816-a200-33ae3cfd8535', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'd975de92-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('4fe987da-7a92-47f1-923b-6bf9c2478df7', 'b459daa4-f776-11ee-baf0-c01803d4a116', '799466dd-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('5200582d-977c-406c-89d7-7f04d39ac5e4', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('52b3df49-0e0a-4c40-acf1-f76ece11cd8f', 'dde498b7-507d-48fc-8e45-051fabfd849e', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:43:03', '2024-04-08 03:43:03', 0, NULL, NULL),
('5513b681-41f1-4739-8b03-f8f2835867a0', 'd7f695ea-58b9-4e32-888f-201490402802', 'dd00b44f-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('552b94d4-da70-452c-8871-921b97b2785e', 'b459daa4-f776-11ee-baf0-c01803d4a116', '3c9491b1-36d1-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('558a64c7-3979-4ea2-b8a2-ae05b24ae988', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('565fe64d-1fa9-4192-8be4-1484c8434959', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', 'dd00ad1b-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('56dad0df-9d7d-4c61-933a-c5c556d9b50a', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'c3751b5f-0df6-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('570dcd85-84f6-4269-bfae-3b6acf6cc6cf', 'c9795f8f-fe90-483e-9731-1e778562fe9a', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 13:35:26', '2024-04-03 13:35:26', 0, NULL, NULL),
('58530677-7005-446a-9ce6-2b64449200ae', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '25b8c824-1c5a-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('58a34580-19f3-4c6b-8a41-aefe11efc79a', 'b459daa4-f776-11ee-baf0-c01803d4a116', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('597c3f36-e973-46d1-a8be-12c1905d4fd0', 'd7f695ea-58b9-4e32-888f-201490402802', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('5a0a7c85-9af6-417c-a871-57fa8dc3caac', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'dce2f829-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('5a1108c2-275f-451c-8ca5-5902ed21234c', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('5b7d5093-e389-48d8-9001-73f7dc72c3e5', 'd81e5ec0-050c-43b3-a9ab-164f641f888c', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 10:43:24', '2024-04-03 10:43:24', 0, NULL, NULL),
('5e27e97a-a0cc-45d8-8ac1-5a7c6d0578dc', 'b459daa4-f776-11ee-baf0-c01803d4a116', '306a3e55-2241-11ef-a40a-c01803d49f59', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('5ef646b2-67d0-4000-8f9c-0471cb1f2ea9', 'd7f695ea-58b9-4e32-888f-201490402802', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('5fb291f3-a2c7-4bef-b14b-7c64c708e7bd', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'f50a1cc4-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('63132404-55ec-4837-9bee-afd9e7acc29e', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('636a337d-5571-41e7-b3da-582f96311cb1', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '62a21d4f-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('63e0f89a-1198-4c79-b334-197681a21522', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('649a2503-340d-47ab-ae05-d730204c1160', 'ae141d4e-7d8b-4272-9989-78d66ee9f1fb', '0f94a3e8-0da4-11ef-84b6-b48c9dac3d22', NULL, NULL, '2024-05-16 11:27:26', '2024-05-16 11:27:26', 0, NULL, NULL),
('64f8bcad-9627-4c47-8004-27880bdbba3f', '9a638616-fb34-4b1f-9c09-6c94e82657ff', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:53:28', '2024-04-03 08:53:28', 0, NULL, NULL),
('655683e7-7318-44ec-9cf7-9306aa5e869e', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('66a27901-1dd1-4cd2-b78b-512f0edc069c', '636f3125-8244-426c-8905-cf8b5045aacd', '25b8c824-1c5a-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-01 13:09:52', '2024-07-01 13:09:52', 0, NULL, NULL),
('6829dca9-4b78-42ae-9d25-cbe01b068745', 'b459daa4-f776-11ee-baf0-c01803d4a116', '62a21d4f-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('683c3ed3-6228-4ddc-a3fe-61f7c2736808', '3e897d67-4ae8-4c87-81f0-4d8698ae41f5', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:25:53', '2024-04-08 03:25:53', 0, NULL, NULL),
('68d39520-e975-44d7-9ad8-ee60625892ec', '0751ec67-a1a1-4cf0-ad0f-f8feead82e42', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 07:21:00', '2024-06-21 11:20:08', 1, '2024-06-21 11:20:07', '0968dca1-d770-4762-ab55-cee664225974'),
('68f12380-4e98-418d-9356-e914dc0ebbb5', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'b5d82d4a-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('6b19d1be-c5f5-4fb8-a06f-e20fe05dd677', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '3c9491b1-36d1-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('6b2fb72c-5f49-4d9f-8f10-aa1496dfd1a3', '6e74a62a-ecd1-4025-97ce-c189232586b3', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:35:57', '2024-04-08 03:35:57', 0, NULL, NULL),
('6c845b07-5ff5-4176-899b-0d8302801afb', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'f50a1cc4-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('6cad6bd6-484b-400c-8a67-06038c8c47de', 'd7f695ea-58b9-4e32-888f-201490402802', '7cacae67-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('6ceb55d6-b198-4af0-90ee-e616df23e4e8', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', 'c5c6eeb6-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('6f476c81-633f-4b82-8c74-b65b16bf1db4', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', '62a22447-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('7002fecf-3e79-4e3a-a54d-ba9b55e972fc', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('708cbea1-250d-4518-b202-6e22c635a113', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('720439fe-9abc-4b7c-b3f3-b893ec1a78e5', 'b459daa4-f776-11ee-baf0-c01803d4a116', '55094e25-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('73090dc7-6819-4609-8020-347d28404000', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'ee4921a4-0df2-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('736da497-3dda-494e-8370-0151db746970', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'fd0f6b57-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('7426fa7a-599e-4ba2-b5df-2f6fb2974879', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'c2064335-0df7-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('75bf6cec-ee98-42c5-bc28-6dc30c611c4e', '24c1e2e7-d7e8-479f-8503-7ced3fa721e0', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:30:45', '2024-04-08 03:30:45', 0, NULL, NULL),
('77a406d6-fe5e-4432-9487-95085423f133', 'b459e14e-f776-11ee-baf0-c01803d4a116', '55094e25-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('7cbf226b-0065-4a2b-9354-0eef6a6a87ae', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('7d3df18b-8f88-4571-85ed-4de391497365', '636f3125-8244-426c-8905-cf8b5045aacd', '85e8d424-0df3-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-01 13:09:52', '2024-07-01 13:09:52', 0, NULL, NULL),
('7d7dbf0c-4691-4e75-845a-5dfba47d63c8', 'ae141d4e-7d8b-4272-9989-78d66ee9f1fb', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-05-16 11:27:26', '2024-05-16 11:27:26', 0, NULL, NULL),
('81514dbd-4942-4415-ada6-97a77356c575', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', '74118ed8-36c3-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('81d8a0ac-da25-408d-aea3-19d5b3159190', 'd7f695ea-58b9-4e32-888f-201490402802', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('82276427-278d-4c63-bb8c-023d2147953e', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('823afa9c-3395-462f-8b4b-3a2c6d453289', 'f07fd946-1dce-490e-aacb-f862d5425d07', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 09:13:38', '2024-04-03 09:13:38', 0, NULL, NULL),
('82f8d0c3-31dc-4229-9234-78f9efeb28b5', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'fd0f8432-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('82fa0fd9-9738-464b-92a9-e891bf45996e', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '306a3e55-2241-11ef-a40a-c01803d49f59', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('82fd7f43-b7dd-4434-9abc-7ba4453473d2', '99eee55b-5681-4c3e-bd40-c4eb4af2ba2a', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:42:47', '2024-04-03 08:42:47', 0, NULL, NULL),
('830ed221-bee2-42b1-8dfc-d1693c790944', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'd03a82c9-f775-11ee-baf0-c01803d4a116', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('8338efd8-cad2-4221-8ff9-cedc4f5b8f7c', '9acbeb94-bc30-4872-96f1-b5540cb83402', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('841e3bc5-272b-4e8f-b828-838d4c72ce35', 'c9795f8f-fe90-483e-9731-1e778562fe9a', '7cacae67-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 13:35:27', '2024-04-03 13:35:27', 0, NULL, NULL),
('85cd6617-ddf8-48d1-aa48-592fd3a734b3', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('8845dfb2-9b3f-4827-bddf-c5997e17c7ec', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('8868acf7-7b51-4d5f-bdeb-3851b534ee59', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('89d80beb-516d-412f-9ab3-a40bfc94d692', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('89d9384d-6894-456b-a142-ecc299cc6731', 'f90e743d-6a81-440d-8039-5354e4262f8f', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:49:46', '2024-04-03 08:49:46', 0, NULL, NULL),
('8a1b757b-2da8-4fbd-90b5-005b733b88c6', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'c5c6eeb6-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('8a79e73d-78d7-439b-b343-740ab5ceede6', '3e897d67-4ae8-4c87-81f0-4d8698ae41f5', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:25:53', '2024-04-08 03:25:53', 0, NULL, NULL),
('8bfe7302-f441-42d7-a212-2a7a7bde5a3c', '7751f2b0-05a8-4cf4-8407-0ac1e3a969af', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:51:32', '2024-04-03 08:51:32', 0, NULL, NULL),
('8e2b0408-02fc-4d19-addc-30ca83f9a9be', 'd7f695ea-58b9-4e32-888f-201490402802', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('8e5fc6ca-b6f2-469e-93e4-6ff498d4ffd4', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'dd00b44f-fdab-11ee-889c-c01803d475fg', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('8e682ae2-8821-4946-b879-894602963169', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('922413a0-e50b-42b1-a2df-7f58b22af41f', '636f3125-8244-426c-8905-cf8b5045aacd', '74118ed8-36c3-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-01 13:09:53', '2024-07-01 13:09:53', 0, NULL, NULL),
('924c1706-ea14-4150-9e6b-4b6c93dcf106', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('94af987a-283d-4f70-8fa4-67a57e32bfa5', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '7cacae67-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('965b0958-0ebf-49ac-af96-258f7aef6263', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('96acf29c-7d15-4fd1-b044-9f5248d054ce', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '9f3a1a3e-440b-11ef-8e35-b05cda965850', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('9786f891-70bb-483e-b53d-84bb66e8f310', 'c1b0890d-99ac-4722-9990-5db4fc5cf669', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-14 08:15:36', '2024-04-14 08:15:36', 0, NULL, NULL),
('98970afa-1773-4cad-b119-d0f0d70f8479', 'bf595b68-63b4-43e8-9df8-26e5d4f33252', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:58:43', '2024-04-03 08:58:43', 0, NULL, NULL),
('995bba97-514b-4f08-ba4c-a77069ac9d8e', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'e562bfc8-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('9a68d746-05f8-4152-9ce9-c6a4b4868ac7', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'dd00ad1b-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 13:02:42', '2024-07-17 13:02:42', 0, NULL, NULL),
('9a98f264-af71-4801-a8bd-96785f729586', 'b516e9d3-b618-4d40-aba3-69c8a832f531', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:50:00', '2024-04-03 08:50:00', 0, NULL, NULL),
('9bd15b76-25cc-41bf-86ea-aeafd8702cd1', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '64383a86-36d1-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-17 13:02:42', '2024-07-17 13:02:42', 0, NULL, NULL),
('9c3abaff-c558-49e1-a6cb-9c13f5de612a', 'b459daa4-f776-11ee-baf0-c01803d4a116', '550954bf-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('9c8ae1b8-ee5e-4bb3-9a53-7a3438321d77', 'b459e14e-f776-11ee-baf0-c01803d4a116', '62a21d4f-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('9e062272-6e15-449e-bc96-5c3cedc13fb3', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('a0d4d609-64c3-420e-9fba-7dbfea657170', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('a1dda983-344c-49ac-b3e0-04d39930cc29', '6ba80e98-5393-4eb1-bfe2-5405be8d6b18', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-16 13:22:30', '2024-04-16 13:22:30', 0, NULL, NULL),
('a470d196-34b9-4e6c-aead-4e0c2bb90daf', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('a4c2bce7-0cc8-4747-b9dc-b2845ae4bfda', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('a4c77b0c-a04d-49c1-97f9-3eb22d18cbc1', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '921e960f-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('a54224cb-ffc2-4c63-b880-1733a4315f73', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '8bc30fe2-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('a564d26b-9981-4a9d-bd81-08a7a10b88f4', '9acbeb94-bc30-4872-96f1-b5540cb83402', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('a57c4d35-2106-444e-8fff-33c5e1f5509f', '9acbeb94-bc30-4872-96f1-b5540cb83402', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('a613b63c-0424-47d8-99a2-f9de9656d5f3', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'b5d82643-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('a6dbd95f-427c-4f26-8e70-6503eb3d3b95', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '6031481e-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('a70541b5-5a75-4ba3-b02b-5d9a12588b06', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'b5d82d4a-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('aa93973c-01b5-4394-ac5f-ee4a73ef7dfc', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('aad0bbd0-073e-45e3-9073-fe123971d511', 'ceacd372-d6a2-453e-99a9-1709036f52d9', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-22 17:10:06', '2024-04-22 17:10:06', 0, NULL, NULL),
('ab475b9d-7719-40e4-9857-5f44bd1aa77c', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'd1bdedf8-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('ad4c0226-3f4d-480c-8d21-c43269e8f635', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('adc1f26c-d3ad-4cbf-bfb9-41b895757161', 'd7f695ea-58b9-4e32-888f-201490402802', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('ae6be8ca-b505-44aa-b146-c280fda76306', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('ae710b2e-4cb4-46c3-b8e8-8e89372716b0', '508dd36f-c85d-442e-b66e-17a58dea2274', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 09:00:54', '2024-04-03 09:00:54', 0, NULL, NULL),
('af59a829-2141-4551-b687-29f0db3dc62a', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'ee4928bc-0df2-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('b0157e9d-8053-4c8e-abd7-644fa6002073', 'b459daa4-f776-11ee-baf0-c01803d4a116', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('b111068a-85fb-4755-8cc6-de9faf9bc48c', '0c11eb79-7ac8-43b5-82c6-74e920b7a0c3', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:34:55', '2024-04-08 03:34:55', 0, NULL, NULL),
('b19a2af8-dbff-4252-ad37-a4c792b9f1d8', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'b5d82d4a-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('b226c065-3734-4b82-aa0f-c66b1eed2b48', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '6fe619f9-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('b297e191-deea-41eb-bf49-74a40d5f71fe', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'e168618d-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('b2ba8ba1-9632-4df3-b67b-6864e0782a31', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '7cacae67-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('b2c307d6-1f6a-426c-8369-f72d6e0db6d8', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('b4090fca-6384-49ba-8cc6-419c5256b51d', '636f3125-8244-426c-8905-cf8b5045aacd', 'd1bdedf8-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-01 13:09:52', '2024-07-01 13:09:52', 0, NULL, NULL),
('b433ac1b-3b6c-491e-a37e-a139b5bfadb8', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('b558b8f9-e3fc-4549-8389-4d9d1650ebc0', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'c5c6f7ad-fdab-11ee-889c-c01803d475fe', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('b57445ee-1ca0-4431-bb4e-da4a6621c3bc', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('b5770cd4-e633-4f53-870f-7930ade0bbed', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('b5db8f15-02bc-4184-b52b-56543221a124', 'f90e743d-6a81-440d-8039-5354e4262f8f', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:49:46', '2024-04-03 08:49:46', 0, NULL, NULL),
('b6bd6c1d-5962-4b2e-8a61-234165968163', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'c2064335-0df7-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('b72468a9-b060-4b31-bb0f-ae1683949e65', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', 'c5c6f7ad-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('b7bca34d-72f6-42b0-a4e8-f8db20e7301a', 'd7f695ea-58b9-4e32-888f-201490402802', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('b8ec3d38-e241-4433-9e4a-fde41f0a89ef', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '4673d532-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('b9f5cb66-223c-4781-9a33-7ce31b5defac', 'b459daa4-f776-11ee-baf0-c01803d4a116', '74118ed8-36c3-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-17 07:12:54', '2024-07-17 07:12:54', 0, NULL, NULL),
('ba6c5380-52d3-44bd-bd17-1da981945abc', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('ba77e542-eb5c-4d66-b9de-63c53326e3ff', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'e168618d-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('bacb39f2-6fbf-4ddd-8035-22bcbe67c461', 'b459daa4-f776-11ee-baf0-c01803d4a116', '921e960f-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('bb2c63dd-57a6-49e6-a103-7144fba5d222', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'dce2fde1-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('bd15666c-7cfb-4bdc-a4ad-277a91131ecc', 'a712d7ee-eebb-496e-ab69-bc450abe0845', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-04 13:19:10', '2024-04-04 13:19:10', 0, NULL, NULL),
('bd9af214-5c56-4011-9031-707e46800183', '20f70065-4eb1-4e31-8ee0-36bcc6b6a13a', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 09:19:45', '2024-04-03 09:19:45', 0, NULL, NULL),
('bf2427e1-afe0-4b60-ad69-a1a1b07fed4a', 'c1b0890d-99ac-4722-9990-5db4fc5cf669', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-14 08:15:36', '2024-04-14 08:15:36', 0, NULL, NULL),
('c0ffe412-a8d2-4520-8896-48c7f43a6095', 'dd5cade5-4809-4417-bebe-76c0daff162b', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:27:51', '2024-04-08 03:27:51', 0, NULL, NULL),
('c2d3535d-1ff9-4c8b-a305-4bf7c274ba51', 'a3b234f2-5540-408b-b838-0020145a761a', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-16 08:53:14', '2024-04-16 08:53:14', 0, NULL, NULL),
('c32594e2-1d73-4839-9822-ae3708972728', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'f50a1cc4-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-06-24 11:01:22', '2024-06-24 11:01:22', 0, NULL, NULL),
('c3a75df8-ca27-4579-9ae0-aa3a2750766c', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '8bc31df5-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('c6d609e3-6dc0-40ee-88cd-40168d4cfcd7', '77b9e901-bd00-4317-855d-24466a4f761b', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:56:32', '2024-04-03 08:56:32', 0, NULL, NULL),
('c7e59808-cadd-4c9e-9cc4-0107e39b7d3f', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '8bc31df5-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('c8b21004-7e0d-4475-8daa-2135cb5a817c', 'd7f695ea-58b9-4e32-888f-201490402802', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('c8ce2319-95d8-437b-bd37-d76a83c85df9', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'fd0f7821-1e4d-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('c9b57d12-196f-4b33-9053-5043f7a2c524', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('ca44c9e0-c60b-4a0f-a867-6260e44aee6c', 'dde498b7-507d-48fc-8e45-051fabfd849e', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:43:04', '2024-04-08 03:43:04', 0, NULL, NULL),
('cc68fcbf-b52f-4da2-8e15-ff03bb90f799', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('cc99e5ce-e53a-4b4a-b1dc-513b549552b2', 'e6fe9df1-80a9-46b2-b58b-71ab703ce176', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-14 07:38:43', '2024-04-14 07:38:43', 0, NULL, NULL),
('cd147497-fd07-4f07-9558-5c26b4a18e48', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-27 12:18:28', '2024-04-27 12:18:28', 0, NULL, NULL),
('cd208620-e805-4593-9aaa-69b2014d7ace', '7055b9e5-5e7d-4e5a-818f-739306b82d4a', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-16 13:21:36', '2024-04-16 13:21:36', 0, NULL, NULL),
('ce1b3ac0-d1f1-4c42-bc43-6dc38de1ca93', 'a712d7ee-eebb-496e-ab69-bc450abe0845', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-04 13:19:10', '2024-04-04 13:19:10', 0, NULL, NULL),
('cede2356-acee-43de-be77-85f41237c9d2', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '799466dd-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('cf136365-446b-4027-8b16-c481e9d0f0f4', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', '64383a86-36d1-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('d03a010b-a13b-4496-ae7f-3cc0ddec4eab', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '86ae5a26-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('d0c83460-7e36-45c9-8de0-e29bc0140c7e', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', '85e8d424-0df3-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('d0dcd275-438c-4be4-a5fd-b1e729021314', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'ae7ba5bb-440b-11ef-8e35-b05cda965850', NULL, NULL, '2024-07-17 07:12:56', '2024-07-17 07:12:56', 0, NULL, NULL),
('d0fc25e8-bbd3-4165-9fe5-d0f23795e5a2', '89c3841e-67e3-41da-bc37-9e7da92fac45', '042b3d2d-f0bd-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-14 07:38:00', '2024-04-14 07:38:00', 0, NULL, NULL),
('d1169ad3-32b9-4acb-9112-049185c121fd', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('d47d5876-3f78-423f-a071-54b8db427bd2', '0751ec67-a1a1-4cf0-ad0f-f8feead82e42', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 07:21:00', '2024-06-21 11:20:08', 1, '2024-06-21 11:20:07', '0968dca1-d770-4762-ab55-cee664225974'),
('d6088e04-04cb-485f-8649-3410cc551988', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'e168618d-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('d79866e9-2c00-4498-ac2c-6d8e65a50a84', '636f3125-8244-426c-8905-cf8b5045aacd', '4673c802-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-07-01 13:09:51', '2024-07-01 13:09:51', 0, NULL, NULL),
('d86c245f-6383-4950-97ef-7f8c54c58c66', '636f3125-8244-426c-8905-cf8b5045aacd', '64383a86-36d1-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-01 13:09:52', '2024-07-01 13:09:52', 0, NULL, NULL),
('da141697-b9b5-484e-ae21-8e523efb53cd', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'b5d82643-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('dbc612db-a7b0-4c5a-844d-cd10a8219b07', '7cf747b6-dfe0-4bdc-adab-558240fd1665', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 09:18:01', '2024-04-03 09:18:01', 0, NULL, NULL),
('dc7dea16-df92-4097-9338-1f59e1f31a07', 'd7f695ea-58b9-4e32-888f-201490402802', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('dcba3d48-9f2e-4032-a801-ccedc5b01f74', 'b4820f3e-b0d6-4370-ae2c-52442b993be2', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 10:42:59', '2024-04-03 10:42:59', 0, NULL, NULL),
('dcf91876-1855-431d-a805-33a823f980e8', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '37959d81-1355-11ef-bcd0-b05cda965850', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('de1a6412-f7b0-4c7a-a0e6-30ee2d23b543', 'dde498b7-507d-48fc-8e45-051fabfd849e', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:43:04', '2024-04-08 03:43:04', 0, NULL, NULL),
('de9975d9-6984-4016-a64e-5c4301bd3743', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'b4315a39-36c3-11ef-a7a0-c01803d49f59', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('df242c29-50ad-42f0-820e-6c57f77eeb49', 'b459e14e-f776-11ee-baf0-c01803d4a116', '4673c802-1e4e-11ef-be51-b05cda965850', NULL, NULL, '2024-06-24 11:01:21', '2024-06-24 11:01:21', 0, NULL, NULL),
('dfabf716-cced-4553-b3fe-05ae58c788f8', '9acbeb94-bc30-4872-96f1-b5540cb83402', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:19:12', '2024-04-03 08:19:12', 0, NULL, NULL),
('e005a545-4b94-4d4e-9b46-140ebfbee694', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL),
('e081efee-8139-41d5-b419-56bfab776cbf', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'be30828d-3388-11ef-813a-b05cda965850', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('e1554171-9c4c-4149-bc79-6d9b8d33c1be', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', 'dd00b44f-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('e1aa7c3a-5120-484a-9317-895661b9b238', 'ae141d4e-7d8b-4272-9989-78d66ee9f1fb', '0f94acc0-0da4-11ef-84b6-b48c9dac3d22', NULL, NULL, '2024-05-16 11:27:26', '2024-05-16 11:27:26', 0, NULL, NULL),
('e2a6d8e2-0551-48dc-bb32-577074ee307f', 'c9795f8f-fe90-483e-9731-1e778562fe9a', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 13:35:26', '2024-04-03 13:35:26', 0, NULL, NULL),
('e35ef80c-e418-416a-bba5-aa1bf74d8eea', 'd7f695ea-58b9-4e32-888f-201490402802', '8bc30fe2-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-18 17:54:50', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('e3795ff5-cd47-4ad0-a222-2ee54bb32929', '4322e34d-f2b6-4bce-9673-3f87e42d8dc1', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 07:36:35', '2024-04-03 07:36:35', 0, NULL, NULL);
INSERT INTO `role_has_permissions` (`role_permission_id`, `role_id`, `permission_id`, `created_by`, `updated_by`, `createdAt`, `updatedAt`, `is_deleted`, `deletionAt`, `deletedBy`) VALUES
('e4def932-07ff-4c91-a90a-86d145b76ef8', 'd7f695ea-58b9-4e32-888f-201490402802', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('e52d7ea7-3975-4906-af8d-3c00c3f75546', '636f3125-8244-426c-8905-cf8b5045aacd', 'f50a1cc4-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-01 13:09:52', '2024-07-01 13:09:52', 0, NULL, NULL),
('e662a700-a784-4575-8efc-54fbe23a3feb', 'b459e14e-f776-11ee-baf0-c01803d4a116', 'dce2fde1-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-06-24 11:01:21', '2024-06-24 11:01:21', 0, NULL, NULL),
('e6a11738-bd7d-43bb-b692-fd827ab9a027', 'dde498b7-507d-48fc-8e45-051fabfd849e', '2f33c5e4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:43:03', '2024-04-08 03:43:03', 0, NULL, NULL),
('e6e89bf8-86bf-483b-af17-ca1726b6c333', '8348b2fd-b7d1-49d0-a0b3-acc8357238e6', '7cacae67-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:26:35', '2024-04-18 17:26:35', 0, NULL, NULL),
('e952ed41-e6fb-46fc-bf95-2a63c5700c70', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'ee4928bc-0df2-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('ea7ae6fd-bf4e-4cbd-977d-54547546d89d', '9b01ad04-c08b-4534-bc00-5f572d169687', '355eef05-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 07:34:39', '2024-06-21 11:20:13', 1, '2024-06-21 11:20:12', '0968dca1-d770-4762-ab55-cee664225974'),
('ebf6c02a-b08f-4c24-b311-c67d35eef499', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '20912e6d-1f53-11ef-be51-b05cda965850', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('ec545139-1a24-4c9c-ae87-c4828fe73fe5', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'f50a1cc4-1c57-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('ed01c3d7-d8b9-4357-a01e-b318327a384a', '9acbeb94-bc30-4872-96f1-b5540cb83402', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('ee797f2f-c07a-4068-bf27-35d857cd8de9', '84fee8c5-9919-4b7a-88c8-225f1a81efe7', '555b9d74-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:41:11', '2024-04-08 03:41:11', 0, NULL, NULL),
('ef075f5c-bd9c-47f2-aada-6fd06f932155', '6ba80e98-5393-4eb1-bfe2-5405be8d6b18', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-16 13:22:30', '2024-04-16 13:22:30', 0, NULL, NULL),
('f11ecd2d-f595-4dde-8dba-097316a3d49a', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'dce2f829-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('f23fed4f-fffb-4f3f-b6ff-be526e074a75', 'b459daa4-f776-11ee-baf0-c01803d4a116', 'dd00ad1b-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-17 07:12:55', '2024-07-17 07:12:55', 0, NULL, NULL),
('f29fbcd0-90f7-4758-b3b2-0609756a6ec3', '09b77e81-f7cf-11ee-aa0f-c01803d4a116', 'dd00ad1b-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-07-04 08:10:49', '2024-07-04 08:10:49', 0, NULL, NULL),
('f4783dfe-ce9f-45f3-aaba-1b0b54f69184', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'a5488f51-1c56-11ef-bb5b-b05cda965850', NULL, NULL, '2024-07-17 13:02:43', '2024-07-17 13:02:43', 0, NULL, NULL),
('f4a71e2f-ed7f-4bbd-8388-5c26d32c57b5', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'dce2f829-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('f4d59244-56a9-4639-8f2b-ea62ea3ac094', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '0f94a3e8-0da4-11ef-84b6-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('f59c6ecb-9cdc-4283-b0c1-485b54ffa160', 'd7f695ea-58b9-4e32-888f-201490402802', '7cacb6b1-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('f61836f9-2627-4c4c-a6fe-493c0897d6fe', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', 'c3751b5f-0df6-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:45', '2024-07-17 13:02:45', 0, NULL, NULL),
('f6467826-f1e0-48a8-90db-8fd8072ec734', 'e2d885eb-cbba-4686-97c5-e7411989826c', '2f33cdc1-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-08 03:36:27', '2024-04-08 03:36:27', 0, NULL, NULL),
('f67e294e-f237-44af-bb40-720f05f95b62', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '55094e25-0df5-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('f75559b2-c186-44e7-a1a7-950637550e2f', 'dde498b7-507d-48fc-8e45-051fabfd849e', '86ae647e-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:43:04', '2024-04-08 03:43:04', 0, NULL, NULL),
('f7a78235-d694-4579-b6cc-430d02e7a21c', 'b6d22469-4895-4905-9503-16ca4e2502ab', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-14 07:36:57', '2024-04-14 07:36:57', 0, NULL, NULL),
('f7da9f0b-a6b7-4ece-8f9b-303ce86a8d4d', '9acbeb94-bc30-4872-96f1-b5540cb83402', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 08:19:13', '2024-04-03 08:19:13', 0, NULL, NULL),
('f8404aad-5efa-4958-892e-f7d04006825a', 'c9795f8f-fe90-483e-9731-1e778562fe9a', '555ba555-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-03 13:35:26', '2024-04-03 13:35:26', 0, NULL, NULL),
('f8937b00-97cc-4699-8738-1ebcce95ce35', 'd7f695ea-58b9-4e32-888f-201490402802', '414c2ab4-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-18 17:54:49', '2024-06-21 11:21:28', 1, '2024-06-21 11:21:28', '0968dca1-d770-4762-ab55-cee664225974'),
('f955c0bb-9457-4982-a469-26d0e77b84f1', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '9907e4ed-0da5-11ef-84b6-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('fabd5c6d-bb8f-4e46-bebe-1eb795a4674c', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '79946ef6-0df4-11ef-9350-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:46', '2024-07-17 13:02:46', 0, NULL, NULL),
('fb4d7090-cc9d-43e5-80ca-3e8dc5f44a64', '3e897d67-4ae8-4c87-81f0-4d8698ae41f5', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-08 03:25:53', '2024-04-08 03:25:53', 0, NULL, NULL),
('fb8f4fe8-f3f5-419a-80e1-46cc85e0e7bb', 'b6d22469-4895-4905-9503-16ca4e2502ab', '355ef6c3-f0b9-11ee-a446-c01803d475fd', NULL, NULL, '2024-04-14 07:36:57', '2024-04-14 07:36:57', 0, NULL, NULL),
('fbc8a10c-7c12-4cda-b166-fb06258d66b0', '891fb4e5-6936-4ca9-8626-1a677bbd2be6', '8bc30fe2-fdab-11ee-889c-c01803d475fd', NULL, NULL, '2024-04-27 12:18:29', '2024-04-27 12:18:29', 0, NULL, NULL),
('fe213e8c-d6da-4a0a-978c-6345300220cd', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', '9907dce2-0da5-11ef-84b6-b48c9dac3d22', NULL, NULL, '2024-07-17 13:02:44', '2024-07-17 13:02:44', 0, NULL, NULL),
('fe2426a1-83d8-4c1d-9818-109ae7f41a3f', '42cf3984-740d-4d4f-9138-ad598ee802a6', '414c220c-f009-11ee-bd81-c01803d475fd', NULL, NULL, '2024-04-03 10:45:27', '2024-04-03 10:45:27', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sectors`
--

CREATE TABLE `sectors` (
  `sector_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `leader_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sequelizemeta`
--

CREATE TABLE `sequelizemeta` (
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `socialmedias`
--

CREATE TABLE `socialmedias` (
  `media_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `general_url` varchar(255) DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subtask_members`
--

CREATE TABLE `subtask_members` (
  `subtask_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `sub_task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `project_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sub_tasks`
--

CREATE TABLE `sub_tasks` (
  `sub_task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `subtask_status` varchar(255) NOT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_milestone` tinyint(1) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `activity_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `task_status` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `is_milestone` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `task_members`
--

CREATE TABLE `task_members` (
  `task_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `project_member_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `task_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `team_manager_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `division_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `first_time_status` tinyint(1) NOT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `unchanged_password` varchar(255) DEFAULT NULL,
  `division_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `refreshToken` varchar(255) DEFAULT NULL,
  `team_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_division_leader` tinyint(4) NOT NULL DEFAULT 0,
  `project_status` tinyint(1) DEFAULT NULL,
  `account_status` tinyint(1) DEFAULT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `first_time_status`, `img_url`, `email`, `gender`, `password`, `unchanged_password`, `division_id`, `refreshToken`, `team_id`, `is_division_leader`, `project_status`, `account_status`, `created_by`, `updated_by`, `createdAt`, `updatedAt`, `is_deleted`, `deletionAt`, `deletedBy`) VALUES
('0968dca1-d770-4762-ab55-cee664225974', 'Admin', 1, 'image', 'admin@admin.com', 'M', '$2b$06$O6bZ8/4LTaxT6uZHAKurMOrlrDQMaEw.evtnNEEYl0AqjMrCwUyke', '', '098fae6b-9ab3-4232-b929-bb0e0afd2e98', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmdWxsX25hbWUiOiJBZG1pbiIsImlhdCI6MTcyMTI3NTc3OCwiZXhwIjoxNzIxMzYyMTc4fQ.eHz5YX802490-2Mg07aTXHkFPn6oZGWW8XNiCgYroIg', NULL, 0, 0, 1, NULL, NULL, '2024-04-01 09:46:59', '2024-07-18 04:09:38', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `project_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deletionAt` datetime DEFAULT NULL,
  `deletedBy` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_role_id`, `user_id`, `project_id`, `role_id`, `created_by`, `updated_by`, `createdAt`, `updatedAt`, `is_deleted`, `deletionAt`, `deletedBy`) VALUES
('2131f6e6-443b-11ef-8e35-b05cda965850', '0968dca1-d770-4762-ab55-cee664225974', '', 'c170f434-248d-4e45-a0b0-5101bab7e8e1', NULL, NULL, '2024-07-17 14:49:01', '2024-07-17 14:49:01', 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `activity_members`
--
ALTER TABLE `activity_members`
  ADD PRIMARY KEY (`activity_member_id`),
  ADD KEY `activity_id` (`activity_id`),
  ADD KEY `project_member_id` (`project_member_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `sub_task_id` (`sub_task_id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `activity_id` (`activity_id`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`division_id`),
  ADD KEY `sector_id` (`sector_id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `document_type_id` (`document_type_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `document_types`
--
ALTER TABLE `document_types`
  ADD PRIMARY KEY (`document_type_id`);

--
-- Indexes for table `major_tasks`
--
ALTER TABLE `major_tasks`
  ADD PRIMARY KEY (`Major_task_id`),
  ADD KEY `activity_id` (`activity_id`);

--
-- Indexes for table `major_task_members`
--
ALTER TABLE `major_task_members`
  ADD PRIMARY KEY (`major_task_member_id`),
  ADD KEY `Major_task_id` (`Major_task_id`),
  ADD KEY `project_member_id` (`project_member_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `organizationmedias`
--
ALTER TABLE `organizationmedias`
  ADD PRIMARY KEY (`organization_media_id`),
  ADD KEY `organization_id` (`organization_id`),
  ADD KEY `media_id` (`media_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`organization_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `project_members`
--
ALTER TABLE `project_members`
  ADD PRIMARY KEY (`project_member_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`role_permission_id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `sectors`
--
ALTER TABLE `sectors`
  ADD PRIMARY KEY (`sector_id`);

--
-- Indexes for table `sequelizemeta`
--
ALTER TABLE `sequelizemeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `socialmedias`
--
ALTER TABLE `socialmedias`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `subtask_members`
--
ALTER TABLE `subtask_members`
  ADD PRIMARY KEY (`subtask_member_id`),
  ADD KEY `subtask_id` (`sub_task_id`),
  ADD KEY `project_member_id` (`project_member_id`);

--
-- Indexes for table `sub_tasks`
--
ALTER TABLE `sub_tasks`
  ADD PRIMARY KEY (`sub_task_id`),
  ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `activity_id` (`activity_id`);

--
-- Indexes for table `task_members`
--
ALTER TABLE `task_members`
  ADD PRIMARY KEY (`task_member_id`),
  ADD KEY `project_member_id` (`project_member_id`),
  ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `division_id` (`division_id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_role_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_members`
--
ALTER TABLE `activity_members`
  ADD CONSTRAINT `activity_members_ibfk_1` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  ADD CONSTRAINT `activity_members_ibfk_2` FOREIGN KEY (`project_member_id`) REFERENCES `project_members` (`project_member_id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`sub_task_id`) REFERENCES `sub_tasks` (`sub_task_id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`),
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`);

--
-- Constraints for table `divisions`
--
ALTER TABLE `divisions`
  ADD CONSTRAINT `divisions_ibfk_1` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`sector_id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`);

--
-- Constraints for table `organizationmedias`
--
ALTER TABLE `organizationmedias`
  ADD CONSTRAINT `organizationmedias_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `organizationmedias_ibfk_2` FOREIGN KEY (`media_id`) REFERENCES `socialmedias` (`media_id`);

--
-- Constraints for table `project_members`
--
ALTER TABLE `project_members`
  ADD CONSTRAINT `project_members_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`);

--
-- Constraints for table `task_members`
--
ALTER TABLE `task_members`
  ADD CONSTRAINT `task_members_ibfk_1` FOREIGN KEY (`project_member_id`) REFERENCES `project_members` (`project_member_id`),
  ADD CONSTRAINT `task_members_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
